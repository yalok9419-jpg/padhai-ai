import "dotenv/config";
import express from "express";
import OpenAI from "openai";

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY is not set. Add it to .env before using AI.");
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json({ limit: "12mb" }));
app.use(express.static("public"));

app.post("/api/ask", async (req, res) => {
  try {
    const { question, image } = req.body || {};
    if (!question && !image) return res.status(400).json({ error: "Question or image is required." });

    const content = [];
    content.push({
      type: "input_text",
      text: `You are Padhai AI, a friendly study helper for Nepali students.
Answer mainly in simple Nepali, but keep English terms where useful.
Explain step-by-step, not just the final answer. For math, show the calculation clearly.
If the question is unclear, say what is unclear instead of inventing an answer.
Question: ${question || "Solve/explain the uploaded question."}`
    });

    if (image) {
      content.push({ type: "input_image", image_url: image });
    }

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5",
      input: [{ role: "user", content }],
    });

    res.json({ answer: response.output_text || "उत्तर प्राप्त भएन।" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI service मा समस्या भयो। API key/model सेटिङ जाँच गर्नुहोस्।" });
  }
});

app.listen(port, () => console.log(`Padhai AI running at http://localhost:${port}`));

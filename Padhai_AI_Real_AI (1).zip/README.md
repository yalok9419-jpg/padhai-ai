# Padhai AI — Real AI version

This version connects the app to the OpenAI Responses API.

## Setup
1. Install Node.js.
2. In this folder run:
   npm install
3. Copy `.env.example` to `.env`.
4. Put your API key in `.env` as `OPENAI_API_KEY=...`.
5. Run:
   npm start
6. Open `http://localhost:3000`.

IMPORTANT: Never put the API key inside browser JavaScript or publish it in the app. Keep it on the server in an environment variable.

The `/api/ask` endpoint accepts:
- `question`: text
- `image`: a data URL such as `data:image/jpeg;base64,...`

The frontend can send either or both.
